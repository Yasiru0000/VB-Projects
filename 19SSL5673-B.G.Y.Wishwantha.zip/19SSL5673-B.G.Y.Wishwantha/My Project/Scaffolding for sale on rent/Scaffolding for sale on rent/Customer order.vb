﻿Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational

Public Class Customer_order

    Public Sub populate5()  '(datagired show customer_order)
        Dim query5 As String = "SELECT * FROM customer_order WHERE NIC = '" & conic.Text & "'"

        Using dapter As New MySqlDataAdapter(query5, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Public Sub populate3()  '(datagired show order_items)
        Dim query1 As String = "SELECT * FROM customer_order WHERE Order_Id = '" & txtorder_id.Text & "' And NIC = '" & conic.Text & "' "

        Using dapter As New MySqlDataAdapter(query1, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Public Sub populate2()  '(datagired show customer_order)
        Dim query3 As String = "SELECT 	Order_Id, NIC FROM customer_order  "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub


    Public Sub populate1()  '(datagired show customer_order)
        Dim query2 As String = "SELECT * FROM customer_order  "

        Using dapter As New MySqlDataAdapter(query2, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub


    Public Sub populate4()  '(datagired show order_items)
        Dim query4 As String = "SELECT * FROM customer_order WHERE Order_Id = '" & txtorder_id.Text & "' "

        Using dapter As New MySqlDataAdapter(query4, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub

    Private Sub Customer_order_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
        populate2()
        populate1()
        'Nic combobox list
        Dim quary As String = "SELECT NIC FROM customer"
        Using cmd As New MySqlCommand(quary, conn)
            Using reader As MySqlDataReader = cmd.ExecuteReader()
                conic.Items.Clear()
                While reader.Read()
                    conic.Items.Add(reader("NIC").ToString())
                End While
            End Using
        End Using
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If String.IsNullOrEmpty(txtorder_id.Text) Then
            MessageBox.Show("Order Id is not given")

        ElseIf String.IsNullOrEmpty(conic.Text) Then
            MessageBox.Show("NIC is not given")

        Else
            populate3()
            populate4()

        End If
    End Sub

    Private Sub btnc_Click(sender As Object, e As EventArgs) Handles btnc.Click
        login.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, Button4.Click
        populate2()
        populate1()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        populate5()

        If String.IsNullOrEmpty(conic.Text) Then
            MessageBox.Show("NIC is not given")
        Else
            populate5()

        End If
    End Sub
End Class