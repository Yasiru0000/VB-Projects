﻿Public Class Users
    Public NIC As String
    Public Cus_name As String
    Public Cus_a As String
    Public Cus_m As String
    Public Cus_d As String

    Public Current_quantity As String
    Public Item_price As String
    Public Item_Id As String
    Public Item_name As String

    ' Public Order_Id As String
    Public H_Frame As String
    Public Cross_Bracing As String
    Public Joint_pin As String
    Public Walking_Board As String
    Public Swivel_coupler As String
    Public Tube_20 As String
    Public Tube_10 As String
    Public Tube_5 As String
    Public Order_All_Quantity As String
    Public Last_Date As String
    Public Dates_Required As String
    Public General_price As String

    Public Order_Id As String


End Class
