﻿Imports MySql.Data.MySqlClient

Public Class Customet_information


    Public Sub populate1()  '(datagired show customer)
        Dim query2 As String = "SELECT * FROM customer "

        Using dapter As New MySqlDataAdapter(query2, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Public Sub populate2()  '(datagired show customer)
        Dim query1 As String = "SELECT NIC, Cus_name FROM customer "

        Using dapter As New MySqlDataAdapter(query1, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub

    Public Sub populate3()  '(datagired show customer)
        Dim query3 As String = "SELECT * FROM customer WHERE NIC = '" & conic.Text & "'"

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Public Sub populate4()  '(datagired show customer)
        Dim query4 As String = "SELECT NIC, Cus_name FROM customer WHERE NIC = '" & conic.Text & "'"

        Using dapter As New MySqlDataAdapter(query4, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub

    Private Sub Customet_information_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
        'Nic combobox list
        Dim quary As String = "SELECT NIC FROM customer"
        Using cmd As New MySqlCommand(quary, conn)
            Using reader As MySqlDataReader = cmd.ExecuteReader()
                conic.Items.Clear()
                While reader.Read()
                    conic.Items.Add(reader("NIC").ToString())
                End While
            End Using
        End Using



        populate1()
        populate2()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If String.IsNullOrEmpty(conic.Text) Then
            MessageBox.Show("NIC is not given")

        Else
            populate3()
            populate4()

        End If
    End Sub

    Private Sub btnc_Click(sender As Object, e As EventArgs) Handles btnc.Click
        login.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        populate1()
        populate2()
    End Sub
End Class