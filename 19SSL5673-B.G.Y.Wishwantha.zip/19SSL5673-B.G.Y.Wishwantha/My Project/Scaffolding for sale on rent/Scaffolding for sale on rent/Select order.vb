﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.VisualBasic.Logging
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational

Public Class Select_order

    Public Sub populate()  '(datagired show order_items)
        Dim query3 As String = "SELECT * FROM order_items WHERE Order_Id = '" & txtorder_id.Text & "' "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub

    Public Sub populate2()  '(items table show  )
        Dim query4 As String = "SELECT Item_name, Current_quantity, Item_price FROM item "

        Using dapter2 As New MySqlDataAdapter(query4, conn)
            Dim datatable As New DataTable()
            dapter2.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Private Sub btncontinue_Click(sender As Object, e As EventArgs) Handles btnorder.Click
        If String.IsNullOrEmpty(conic.Text) Then
            MessageBox.Show("Insert Customer NIC")

        ElseIf String.IsNullOrEmpty(txtnodr.Text) Then
            MessageBox.Show("Insert Number of days Required")

        ElseIf String.IsNullOrEmpty(txtorderpr.Text) Then
            MessageBox.Show("Select Items")

        Else


            Dim numberofdDys As Integer = Integer.Parse(txtnodr.Text)
            Dim currentDate As DateTime = DateTime.Now
            Dim Last_Date As DateTime = currentDate.AddDays(numberofdDys)

            cm = New MySqlCommand("INSERT INTO customer_order (NIC, Dates_Required, Last_Date) values(@NIC,@Dates_Required,@Last_Date)", conn)
            cm.Parameters.AddWithValue("NIC", conic.Text)
            cm.Parameters.AddWithValue("Dates_Required", txtnodr.Text)
            cm.Parameters.AddWithValue("Last_Date", Last_Date)

            cm.ExecuteNonQuery()
            MessageBox.Show("Order successful")
        End If

        'ordr kara pasu ilagata thiyana order id eka display kirima
        Dim currentvalue As Integer
        Dim query As String = "SELECT Order_Id FROM customer_order ORDER BY Order_Id DESC LIMIT 1"
        Using command As New MySqlCommand(query, conn)
            currentvalue = CInt(command.ExecuteScalar())
        End Using

    End Sub

    Private Sub RoundButton1_Click(sender As Object, e As EventArgs) Handles btnhome.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        Updaten.Show()
        Me.Hide()
    End Sub

    Private Sub RoundButton3_Click(sender As Object, e As EventArgs)

    End Sub



    Private Sub RoundButton1_Click_1(sender As Object, e As EventArgs) Handles btne.Click
        Me.Close()

    End Sub

    Private Sub Select_order_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()

        'forms eka open weddi ilagata thiyana order id eka display kirima
        Dim currentvalue As Integer
        Dim query As String = "SELECT Order_Id FROM customer_order ORDER BY Order_Id DESC LIMIT 1"
        Using command As New MySqlCommand(query, conn)
            currentvalue = CInt(command.ExecuteScalar())
        End Using

        Dim newid As Integer = currentvalue + 1
        txtorder_id.Text = newid.ToString()

        'items current information datagird view
        Dim dt As New DataTable()
        dt.Columns.Add("Item Name")
        dt.Columns.Add("Current Quantity")
        dt.Columns.Add("Item Price")

        Dim userlist As List(Of Users) = Getusers()
        For Each r As Users In userlist
            dt.Rows.Add(r.Item_name, r.Current_quantity, r.Item_price)
        Next
        dgv1.DataSource = dt

        'Nic combobox list
        Dim quary As String = "SELECT NIC FROM customer"
        Using cmd As New MySqlCommand(quary, conn)
            Using reader As MySqlDataReader = cmd.ExecuteReader()
                conic.Items.Clear()
                While reader.Read()
                    conic.Items.Add(reader("NIC").ToString())
                End While
            End Using
        End Using

        'Item name combobox list
        Dim quary2 As String = "SELECT Item_name FROM item"
        Using cmmd As New MySqlCommand(quary2, conn)
            Using reader As MySqlDataReader = cmmd.ExecuteReader()
                coitem.Items.Clear()
                While reader.Read()
                    coitem.Items.Add(reader("Item_name").ToString())
                End While
            End Using
        End Using

        'Item price combobox list
        Dim quary5 As String = "SELECT Item_name, Item_price FROM item"
        Using cmmdd As New MySqlCommand(quary5, conn)
            Using reader As MySqlDataReader = cmmdd.ExecuteReader()
                coprice.Items.Clear()
                While reader.Read()
                    coprice.Items.Add(reader("Item_name").ToString())
                    coprice.Items.Add(reader("Item_price").ToString())
                End While
            End Using
        End Using

        'quantity lists and default=0 value
        For i As Integer = 0 To 2000

            coquan.Items.Add(i)
        Next

        coquan.SelectedIndex = 0
        txtorderpr.Text = 0


    End Sub

    Public Function Getusers() As List(Of Users)
        'for items current information datagird view 
        Dim selectorder As New List(Of Users)
        connection()
        Dim cm As New MySqlCommand
        Dim B = "SELECT * FROM `item` "
        cm = New MySqlCommand(B, conn)
        Dim result = cm.ExecuteReader

        For Each i In result
            selectorder.Add(New Users With {.Item_name = result("Item_name"), .Current_quantity = result("Current_quantity"), .Item_price = result("Item_price")})
        Next
        result.Close()
        Return selectorder
    End Function

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnu_Click(sender As Object, e As EventArgs)



    End Sub

    Private Sub Label17_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub RoundButton1_Click_2(sender As Object, e As EventArgs) Handles RoundButton1.Click
        Dim Quantityy, it As String

        Quantityy = coquan.Text
        it = coitem.Text


        If String.IsNullOrEmpty(coitem.Text) Then
            MessageBox.Show("Item Name is not given")

        ElseIf Quantityy = 0 Then
            MessageBox.Show("Quantity is not given")

        ElseIf String.IsNullOrEmpty(coprice.Text) Then
            MessageBox.Show("Item Price is not given")

        Else
            'price calculate
            Dim v1 As Integer = Integer.Parse(coquan.Text)
            Dim v2 As Integer = Integer.Parse(coprice.Text)
            Dim re As Integer = v1 * v2
            txttotalprice.Text = re.ToString()

            Dim v3 As Integer = Integer.Parse(txtorderpr.Text)
            Dim re2 As Integer = re.ToString() + v3
            txtorderpr.Text = re2.ToString()


            cm = New MySqlCommand(
                "INSERT INTO order_items  values(@Order_Id,@Item_name,@Quantity,@Total_Price);" &
                 "UPDATE item Set Current_quantity = Current_quantity-'" & coquan.Text & "' WHERE Item_name = '" & coitem.Text & "';", conn)

            cm.Parameters.AddWithValue("Order_Id", txtorder_id.Text)
            cm.Parameters.AddWithValue("Item_name", coitem.Text)
            cm.Parameters.AddWithValue("Quantity", coquan.Text)
            cm.Parameters.AddWithValue("Total_Price", txttotalprice.Text)



            cm.ExecuteNonQuery()
            MessageBox.Show("Item Selected")

            populate()
            populate2()
        End If
    End Sub

    Private Sub RoundButton2_Click(sender As Object, e As EventArgs) Handles RoundButton2.Click
        Update_Customer_Order.Show()
        Me.Hide()
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub btnnadd_Click(sender As Object, e As EventArgs) Handles btnnadd.Click
        If String.IsNullOrEmpty(conic.Text) Then
            MessageBox.Show("Insert Customer NIC")

        ElseIf String.IsNullOrEmpty(txtnodr.Text) Then
            MessageBox.Show("Insert Number of days Required")

        ElseIf String.IsNullOrEmpty(txtorderpr.Text) Then
            MessageBox.Show("Select Items")

        Else


            cm = New MySqlCommand("INSERT INTO customer_pay (Order_Id, NIC, Order_Price, Amounts_Receivable) values(@Order_Id,@NIC,@Order_Price,@Amounts_Receivable)", conn)

            cm.Parameters.AddWithValue("Order_Id", txtorder_id.Text)
            cm.Parameters.AddWithValue("NIC", conic.Text)
            cm.Parameters.AddWithValue("Order_Price", txtorderpr.Text)
            cm.Parameters.AddWithValue("Amounts_Receivable", txtorderpr.Text)

            cm.ExecuteNonQuery()
            MessageBox.Show("Add successful")
        End If
    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        txtorder_id.Text = ""
        conic.Text = ""
        txtnodr.Text = ""
        txtorderpr.Text = 0
        txttotalprice.Text = ""
        coitem.Text = ""
        coquan.Text = ""
        coprice.Text = ""
    End Sub
End Class

