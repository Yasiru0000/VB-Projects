﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient

Public Class Manage_Items

    Public Sub populate()  '(datagired show item)
        Dim query3 As String = "SELECT * FROM item "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Private Sub lbl44444_Click(sender As Object, e As EventArgs) Handles lbl44444.Click

    End Sub

    Private Sub btnn_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        cm = New MySqlCommand("INSERT INTO item (Item_name, Quantity, Current_quantity, Item_price) values(@Item_name,@Quantity,@Current_quantity,@Item_price)", conn)
        cm.Parameters.AddWithValue("Item_name", txtn.Text)
        cm.Parameters.AddWithValue("Quantity", txtquantity.Text)
        cm.Parameters.AddWithValue("Current_quantity", txtCurr.Text)
        cm.Parameters.AddWithValue("Item_price", txtitemp.Text)

        cm.ExecuteNonQuery()
        populate()
        MsgBox("New Item Add")
    End Sub

    Private Sub txtquantity_TextChanged(sender As Object, e As EventArgs) Handles txtquantity.TextChanged

    End Sub

    Private Sub Manage_Items_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
        populate()

    End Sub

    Private Sub btnedit_Click(sender As Object, e As EventArgs) Handles btnedit.Click
        cm = New MySqlCommand("UPDATE item SET Item_Id = '" & txtid.Text & "' , Item_name = '" & txtn.Text & "' , Quantity = '" & txtquantity.Text & "' , Current_quantity = '" & txtCurr.Text & "' , Item_price = '" & txtitemp.Text & "' WHERE Item_Id = '" & txtid.Text & "';", conn)

        cm.ExecuteNonQuery()
        populate()
        MsgBox("Edit Item Add")
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        cm = New MySqlCommand("DELETE FROM item WHERE Item_Id = '" & txtid.Text & "';", conn)

        cm.ExecuteNonQuery()
        populate()
        MsgBox("Item Deleted")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        login.Show()
        Me.Hide()
    End Sub

    Private Sub btnresit_Click(sender As Object, e As EventArgs) Handles btnresit.Click
        txtid.Text = ""
        txtn.Text = ""
        txtitemp.Text = ""
        txtquantity.Text = ""
        txtCurr.Text = ""

    End Sub
End Class