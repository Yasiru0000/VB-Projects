﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Select_order
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Select_order))
        Me.lblid = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtnodr = New System.Windows.Forms.TextBox()
        Me.conic = New System.Windows.Forms.ComboBox()
        Me.lbl44444 = New System.Windows.Forms.Label()
        Me.txtorder_id = New System.Windows.Forms.TextBox()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.coitem = New System.Windows.Forms.ComboBox()
        Me.coquan = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.coprice = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txttotalprice = New System.Windows.Forms.TextBox()
        Me.txtorderpr = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnreset = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnnadd = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.RoundButton2 = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.RoundButton1 = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btne = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnhome = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnback = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnorder = New Scaffolding_for_sale_on_rent.RoundButton()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.BackColor = System.Drawing.Color.Transparent
        Me.lblid.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.ForeColor = System.Drawing.Color.White
        Me.lblid.Location = New System.Drawing.Point(22, 146)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(59, 39)
        Me.lblid.TabIndex = 162
        Me.lblid.Text = "NIC"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Book Antiqua", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Silver
        Me.Label1.Location = New System.Drawing.Point(6, 242)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(396, 64)
        Me.Label1.TabIndex = 170
        Me.Label1.Text = "Items,there current quantities " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and prices"
        '
        'dgv1
        '
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(12, 309)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowHeadersWidth = 51
        Me.dgv1.RowTemplate.Height = 24
        Me.dgv1.Size = New System.Drawing.Size(467, 298)
        Me.dgv1.TabIndex = 183
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(24, 655)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(271, 39)
        Me.Label3.TabIndex = 189
        Me.Label3.Text = "Number of days Required"
        '
        'txtnodr
        '
        Me.txtnodr.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnodr.Location = New System.Drawing.Point(341, 654)
        Me.txtnodr.Multiline = True
        Me.txtnodr.Name = "txtnodr"
        Me.txtnodr.Size = New System.Drawing.Size(87, 30)
        Me.txtnodr.TabIndex = 186
        '
        'conic
        '
        Me.conic.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.conic.FormattingEnabled = True
        Me.conic.Location = New System.Drawing.Point(155, 146)
        Me.conic.Name = "conic"
        Me.conic.Size = New System.Drawing.Size(176, 28)
        Me.conic.TabIndex = 207
        '
        'lbl44444
        '
        Me.lbl44444.AutoSize = True
        Me.lbl44444.BackColor = System.Drawing.Color.Transparent
        Me.lbl44444.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl44444.ForeColor = System.Drawing.Color.White
        Me.lbl44444.Location = New System.Drawing.Point(22, 94)
        Me.lbl44444.Name = "lbl44444"
        Me.lbl44444.Size = New System.Drawing.Size(108, 39)
        Me.lbl44444.TabIndex = 209
        Me.lbl44444.Text = "Order Id "
        '
        'txtorder_id
        '
        Me.txtorder_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorder_id.Location = New System.Drawing.Point(155, 104)
        Me.txtorder_id.Multiline = True
        Me.txtorder_id.Name = "txtorder_id"
        Me.txtorder_id.Size = New System.Drawing.Size(176, 29)
        Me.txtorder_id.TabIndex = 210
        '
        'dgv2
        '
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2.Location = New System.Drawing.Point(594, 309)
        Me.dgv2.Name = "dgv2"
        Me.dgv2.RowHeadersWidth = 51
        Me.dgv2.RowTemplate.Height = 24
        Me.dgv2.Size = New System.Drawing.Size(467, 298)
        Me.dgv2.TabIndex = 230
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(552, 104)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(127, 39)
        Me.Label12.TabIndex = 231
        Me.Label12.Text = "Item Name"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(751, 104)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(108, 39)
        Me.Label13.TabIndex = 232
        Me.Label13.Text = "Quantity"
        '
        'coitem
        '
        Me.coitem.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coitem.FormattingEnabled = True
        Me.coitem.Location = New System.Drawing.Point(559, 146)
        Me.coitem.Name = "coitem"
        Me.coitem.Size = New System.Drawing.Size(176, 28)
        Me.coitem.TabIndex = 233
        '
        'coquan
        '
        Me.coquan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coquan.FormattingEnabled = True
        Me.coquan.Location = New System.Drawing.Point(758, 146)
        Me.coquan.Name = "coquan"
        Me.coquan.Size = New System.Drawing.Size(110, 28)
        Me.coquan.TabIndex = 234
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Book Antiqua", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Silver
        Me.Label2.Location = New System.Drawing.Point(590, 274)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(198, 32)
        Me.Label2.TabIndex = 236
        Me.Label2.Text = "Selected Items"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label4.Location = New System.Drawing.Point(431, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(327, 59)
        Me.Label4.TabIndex = 238
        Me.Label4.Text = "Select Order"
        '
        'coprice
        '
        Me.coprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coprice.FormattingEnabled = True
        Me.coprice.Location = New System.Drawing.Point(888, 146)
        Me.coprice.Name = "coprice"
        Me.coprice.Size = New System.Drawing.Size(162, 28)
        Me.coprice.TabIndex = 239
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(890, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 39)
        Me.Label5.TabIndex = 240
        Me.Label5.Text = "Price:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(733, 235)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(161, 39)
        Me.Label6.TabIndex = 242
        Me.Label6.Text = "Total Price Rs:"
        '
        'txttotalprice
        '
        Me.txttotalprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttotalprice.Location = New System.Drawing.Point(938, 235)
        Me.txttotalprice.Multiline = True
        Me.txttotalprice.Name = "txttotalprice"
        Me.txttotalprice.Size = New System.Drawing.Size(108, 29)
        Me.txttotalprice.TabIndex = 243
        '
        'txtorderpr
        '
        Me.txtorderpr.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorderpr.Location = New System.Drawing.Point(936, 655)
        Me.txtorderpr.Multiline = True
        Me.txtorderpr.Name = "txtorderpr"
        Me.txtorderpr.Size = New System.Drawing.Size(108, 29)
        Me.txtorderpr.TabIndex = 245
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(733, 655)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(168, 39)
        Me.Label7.TabIndex = 244
        Me.Label7.Text = "Order Price Rs:"
        '
        'btnreset
        '
        Me.btnreset.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnreset.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnreset.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreset.ForeColor = System.Drawing.Color.Black
        Me.btnreset.Image = CType(resources.GetObject("btnreset.Image"), System.Drawing.Image)
        Me.btnreset.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnreset.Location = New System.Drawing.Point(206, 180)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(125, 49)
        Me.btnreset.TabIndex = 247
        Me.btnreset.Text = "Reset "
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'btnnadd
        '
        Me.btnnadd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnnadd.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnadd.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnnadd.Image = CType(resources.GetObject("btnnadd.Image"), System.Drawing.Image)
        Me.btnnadd.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnnadd.Location = New System.Drawing.Point(975, 690)
        Me.btnnadd.Name = "btnnadd"
        Me.btnnadd.Size = New System.Drawing.Size(75, 49)
        Me.btnnadd.TabIndex = 246
        Me.btnnadd.Text = "Add "
        Me.btnnadd.UseVisualStyleBackColor = True
        '
        'RoundButton2
        '
        Me.RoundButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RoundButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.RoundButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoundButton2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RoundButton2.Image = CType(resources.GetObject("RoundButton2.Image"), System.Drawing.Image)
        Me.RoundButton2.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.RoundButton2.Location = New System.Drawing.Point(1083, 593)
        Me.RoundButton2.Name = "RoundButton2"
        Me.RoundButton2.Size = New System.Drawing.Size(137, 72)
        Me.RoundButton2.TabIndex = 237
        Me.RoundButton2.Text = "Change Order"
        Me.RoundButton2.UseVisualStyleBackColor = True
        '
        'RoundButton1
        '
        Me.RoundButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RoundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.RoundButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoundButton1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RoundButton1.Image = CType(resources.GetObject("RoundButton1.Image"), System.Drawing.Image)
        Me.RoundButton1.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.RoundButton1.Location = New System.Drawing.Point(1056, 132)
        Me.RoundButton1.Name = "RoundButton1"
        Me.RoundButton1.Size = New System.Drawing.Size(75, 49)
        Me.RoundButton1.TabIndex = 235
        Me.RoundButton1.Text = "Add "
        Me.RoundButton1.UseVisualStyleBackColor = True
        '
        'btne
        '
        Me.btne.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btne.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btne.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btne.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btne.Image = CType(resources.GetObject("btne.Image"), System.Drawing.Image)
        Me.btne.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btne.Location = New System.Drawing.Point(1083, 456)
        Me.btne.Name = "btne"
        Me.btne.Size = New System.Drawing.Size(137, 55)
        Me.btne.TabIndex = 174
        Me.btne.Text = "Exit"
        Me.btne.UseVisualStyleBackColor = True
        '
        'btnhome
        '
        Me.btnhome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnhome.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnhome.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnhome.Image = CType(resources.GetObject("btnhome.Image"), System.Drawing.Image)
        Me.btnhome.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnhome.Location = New System.Drawing.Point(1083, 395)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(137, 55)
        Me.btnhome.TabIndex = 168
        Me.btnhome.Text = "Home"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'btnback
        '
        Me.btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnback.Image = CType(resources.GetObject("btnback.Image"), System.Drawing.Image)
        Me.btnback.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnback.Location = New System.Drawing.Point(1083, 334)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(137, 55)
        Me.btnback.TabIndex = 167
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btnorder
        '
        Me.btnorder.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnorder.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnorder.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnorder.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnorder.Image = CType(resources.GetObject("btnorder.Image"), System.Drawing.Image)
        Me.btnorder.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnorder.Location = New System.Drawing.Point(1083, 671)
        Me.btnorder.Name = "btnorder"
        Me.btnorder.Size = New System.Drawing.Size(137, 72)
        Me.btnorder.TabIndex = 166
        Me.btnorder.Text = "Order"
        Me.btnorder.UseVisualStyleBackColor = True
        '
        'Select_order
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources.square_cubism_form_shape
        Me.ClientSize = New System.Drawing.Size(1245, 755)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.btnnadd)
        Me.Controls.Add(Me.txtorderpr)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txttotalprice)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.coprice)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.RoundButton2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RoundButton1)
        Me.Controls.Add(Me.coquan)
        Me.Controls.Add(Me.coitem)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.dgv2)
        Me.Controls.Add(Me.txtorder_id)
        Me.Controls.Add(Me.lbl44444)
        Me.Controls.Add(Me.conic)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtnodr)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.btne)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnhome)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.btnorder)
        Me.Controls.Add(Me.lblid)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Select_order"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Select_Order"
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnback As RoundButton
    Friend WithEvents btnorder As RoundButton
    Friend WithEvents lblid As Label
    Friend WithEvents btnhome As RoundButton
    Friend WithEvents Label1 As Label
    Friend WithEvents btne As RoundButton
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents txtnodr As TextBox
    Friend WithEvents conic As ComboBox
    Friend WithEvents lbl44444 As Label
    Friend WithEvents txtorder_id As TextBox
    Friend WithEvents dgv2 As DataGridView
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents coitem As ComboBox
    Friend WithEvents coquan As ComboBox
    Friend WithEvents RoundButton1 As RoundButton
    Friend WithEvents Label2 As Label
    Friend WithEvents RoundButton2 As RoundButton
    Friend WithEvents Label4 As Label
    Friend WithEvents coprice As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txttotalprice As TextBox
    Friend WithEvents txtorderpr As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents btnnadd As RoundButton
    Friend WithEvents btnreset As RoundButton
End Class
