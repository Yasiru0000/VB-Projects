﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Receiving_item
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Receiving_item))
        Me.btnback = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btncle = New System.Windows.Forms.Button()
        Me.coquan = New System.Windows.Forms.ComboBox()
        Me.coitem = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtorder_id = New System.Windows.Forms.TextBox()
        Me.lbl44444 = New System.Windows.Forms.Label()
        Me.btnview = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnback
        '
        Me.btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnback.Image = CType(resources.GetObject("btnback.Image"), System.Drawing.Image)
        Me.btnback.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnback.Location = New System.Drawing.Point(923, 456)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(112, 55)
        Me.btnback.TabIndex = 160
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label1.Location = New System.Drawing.Point(305, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(399, 59)
        Me.Label1.TabIndex = 166
        Me.Label1.Text = "Receiving item "
        '
        'btncle
        '
        Me.btncle.BackColor = System.Drawing.Color.Green
        Me.btncle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncle.Location = New System.Drawing.Point(773, 144)
        Me.btncle.Name = "btncle"
        Me.btncle.Size = New System.Drawing.Size(205, 63)
        Me.btncle.TabIndex = 259
        Me.btncle.Text = "Receiving item from customer"
        Me.btncle.UseVisualStyleBackColor = False
        '
        'coquan
        '
        Me.coquan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coquan.FormattingEnabled = True
        Me.coquan.Location = New System.Drawing.Point(640, 162)
        Me.coquan.Name = "coquan"
        Me.coquan.Size = New System.Drawing.Size(110, 28)
        Me.coquan.TabIndex = 265
        '
        'coitem
        '
        Me.coitem.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coitem.FormattingEnabled = True
        Me.coitem.Location = New System.Drawing.Point(450, 162)
        Me.coitem.Name = "coitem"
        Me.coitem.Size = New System.Drawing.Size(176, 28)
        Me.coitem.TabIndex = 264
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(633, 120)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(108, 39)
        Me.Label13.TabIndex = 263
        Me.Label13.Text = "Quantity"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(443, 120)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(127, 39)
        Me.Label12.TabIndex = 262
        Me.Label12.Text = "Item Name"
        '
        'txtorder_id
        '
        Me.txtorder_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorder_id.Location = New System.Drawing.Point(148, 126)
        Me.txtorder_id.Multiline = True
        Me.txtorder_id.Name = "txtorder_id"
        Me.txtorder_id.Size = New System.Drawing.Size(176, 29)
        Me.txtorder_id.TabIndex = 261
        '
        'lbl44444
        '
        Me.lbl44444.AutoSize = True
        Me.lbl44444.BackColor = System.Drawing.Color.Transparent
        Me.lbl44444.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl44444.ForeColor = System.Drawing.Color.White
        Me.lbl44444.Location = New System.Drawing.Point(12, 120)
        Me.lbl44444.Name = "lbl44444"
        Me.lbl44444.Size = New System.Drawing.Size(108, 39)
        Me.lbl44444.TabIndex = 260
        Me.lbl44444.Text = "Order Id "
        '
        'btnview
        '
        Me.btnview.BackColor = System.Drawing.Color.Green
        Me.btnview.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnview.Location = New System.Drawing.Point(658, 243)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 32)
        Me.btnview.TabIndex = 268
        Me.btnview.Text = "View"
        Me.btnview.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Book Antiqua", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.LightGoldenrodYellow
        Me.Label2.Location = New System.Drawing.Point(445, 246)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(198, 32)
        Me.Label2.TabIndex = 267
        Me.Label2.Text = "Selected Items"
        '
        'dgv1
        '
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(450, 281)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowHeadersWidth = 51
        Me.dgv1.RowTemplate.Height = 24
        Me.dgv1.Size = New System.Drawing.Size(467, 438)
        Me.dgv1.TabIndex = 266
        '
        'dgv2
        '
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2.Location = New System.Drawing.Point(19, 167)
        Me.dgv2.Name = "dgv2"
        Me.dgv2.RowHeadersWidth = 51
        Me.dgv2.RowTemplate.Height = 24
        Me.dgv2.Size = New System.Drawing.Size(340, 552)
        Me.dgv2.TabIndex = 269
        '
        'Receiving_item
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources.square_cubism_form_shape
        Me.ClientSize = New System.Drawing.Size(1043, 795)
        Me.Controls.Add(Me.dgv2)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.coquan)
        Me.Controls.Add(Me.coitem)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtorder_id)
        Me.Controls.Add(Me.lbl44444)
        Me.Controls.Add(Me.btncle)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnback)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Receiving_item"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Receiving_goods"
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnback As RoundButton
    Friend WithEvents Label1 As Label
    Friend WithEvents btncle As Button
    Friend WithEvents coquan As ComboBox
    Friend WithEvents coitem As ComboBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents txtorder_id As TextBox
    Friend WithEvents lbl44444 As Label
    Friend WithEvents btnview As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents dgv2 As DataGridView
End Class
