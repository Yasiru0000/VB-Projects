﻿Imports System.Diagnostics.Eventing.Reader
Imports MySql.Data.MySqlClient

Public Class New_order
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtaddress.TextChanged

    End Sub

    Private Sub RoundButton3_Click(sender As Object, e As EventArgs) Handles btnback.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btnnext_Click(sender As Object, e As EventArgs) Handles btnnext.Click
        Dim cusnic, cusn, add, mob, age As String
        Dim datacheck As String

        cusnic = txtnic.Text
        cusn = txtname.Text
        add = txtaddress.Text
        mob = txtmobile.Text
        age = lblage.Text
        datacheck = dtp.Text


        If min_length(cusnic, 9) = False Then
            MsgBox("Need more charactors for NIC")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(cusn, 2) = False Then
            MsgBox("Need more charactors for Name")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(add, 5) = False Then
            MsgBox("Need more charactors for Address")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(mob, 10) = False Then
            MsgBox("Need more charactors for Mobile Number")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(datacheck, 9) = False Then
            MsgBox("Need more charactors for Date Of Birth")
            MsgBox("Data don't saved succesfully")

        Else

            '   cm = New MySqlCommand("INSERT INTO customer (Cus_name, Address, Mobile, Dob, Age) values('" & txtname.Text & "','" & txtaddress.Text & "','" & txtmobile.Text & "','" & dtp.Text & "','" & txtage.Text & "')", conn)
            cm = New MySqlCommand("INSERT INTO customer (NIC, Cus_name, Address, Mobile, Dob, Age) values(@NIC,@Cus_name,@Address,@Mobile,@Dob,@Age)", conn)
            cm.Parameters.AddWithValue("NIC", txtnic.Text)
            cm.Parameters.AddWithValue("Cus_name", txtname.Text)
            cm.Parameters.AddWithValue("Address", txtaddress.Text)
            cm.Parameters.AddWithValue("Mobile", txtmobile.Text)
            cm.Parameters.AddWithValue("Dob", dtp.Text)
            cm.Parameters.AddWithValue("Age", lblage.Text)

            cm.ExecuteNonQuery()
            MsgBox("Create customer id")

            Select_order.Show()
            Me.Hide()
        End If

       ' Dim dt As New DataTable()
        'dt.

       ' cm = New MySqlCommand("Select Cus_Id customer  ")









    End Sub

    Private Sub btnhome_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs)
        Me.Close()

    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles dtp.ValueChanged
        Dim datacheck As String
        Dim today As System.DateTime = System.DateTime.Now
        datacheck = dtp.Text

        Dim yearnow As Integer = today.Year
        Dim yeardtp As Integer = dtp.Value.Year
        Dim rightyear As Integer = dtp.Value.Year
        Dim minimage As Integer = yeardtp - rightyear
        Dim currentage As Integer = yearnow - yeardtp
        lblage.Text = currentage.ToString
        ' txtdob.Text = datacheck.ToString
        lblage.Show()

    End Sub

    Private Sub New_order_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        txtnic.Text = ""
        txtname.Text = ""
        txtaddress.Text = ""
        txtmobile.Text = ""
        lblage.Text = ""
        dtp.Text = ""
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnupdate_Click_1(sender As Object, e As EventArgs)
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtnic.TextChanged

    End Sub

    Private Sub txtmobile_TextChanged(sender As Object, e As EventArgs) Handles txtmobile.TextChanged

    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    ' Public Function Getid() As List(Of Users)
    'Dim 
    'End Function
End Class