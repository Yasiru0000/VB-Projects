﻿Imports MySql.Data.MySqlClient

Public Class login

    Public Sub populate()  '(datagired show item)
        Dim query3 As String = "SELECT * FROM item "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Private Sub login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
    End Sub

    Private Sub btnc_Click(sender As Object, e As EventArgs) Handles btnc.Click
        populate()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Admin_login.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Customer_order.Show()
        Me.Hide()
        'populate()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Order_information_and_Customer.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        customer_pay.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Customet_information.Show()
        Me.Hide()
    End Sub
End Class