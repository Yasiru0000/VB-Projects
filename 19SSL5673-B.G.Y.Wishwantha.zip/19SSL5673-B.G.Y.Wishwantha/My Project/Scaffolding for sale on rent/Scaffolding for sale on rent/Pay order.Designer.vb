﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pay_order
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Pay_order))
        Me.btnback = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btncontinue = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.txtorderid = New System.Windows.Forms.TextBox()
        Me.lbl44444 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.btnview = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtpay = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnback
        '
        Me.btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnback.Image = CType(resources.GetObject("btnback.Image"), System.Drawing.Image)
        Me.btnback.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnback.Location = New System.Drawing.Point(570, 667)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(137, 55)
        Me.btnback.TabIndex = 160
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btncontinue
        '
        Me.btncontinue.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btncontinue.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btncontinue.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncontinue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btncontinue.Image = CType(resources.GetObject("btncontinue.Image"), System.Drawing.Image)
        Me.btncontinue.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btncontinue.Location = New System.Drawing.Point(952, 575)
        Me.btncontinue.Name = "btncontinue"
        Me.btncontinue.Size = New System.Drawing.Size(144, 64)
        Me.btncontinue.TabIndex = 159
        Me.btncontinue.Text = "Pay "
        Me.btncontinue.UseVisualStyleBackColor = True
        '
        'txtorderid
        '
        Me.txtorderid.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtorderid.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorderid.ForeColor = System.Drawing.Color.Black
        Me.txtorderid.Location = New System.Drawing.Point(159, 186)
        Me.txtorderid.Multiline = True
        Me.txtorderid.Name = "txtorderid"
        Me.txtorderid.Size = New System.Drawing.Size(176, 31)
        Me.txtorderid.TabIndex = 157
        '
        'lbl44444
        '
        Me.lbl44444.AutoSize = True
        Me.lbl44444.BackColor = System.Drawing.Color.Transparent
        Me.lbl44444.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl44444.ForeColor = System.Drawing.Color.White
        Me.lbl44444.Location = New System.Drawing.Point(25, 186)
        Me.lbl44444.Name = "lbl44444"
        Me.lbl44444.Size = New System.Drawing.Size(108, 39)
        Me.lbl44444.TabIndex = 248
        Me.lbl44444.Text = "Order Id "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label1.Location = New System.Drawing.Point(487, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(272, 59)
        Me.Label1.TabIndex = 249
        Me.Label1.Text = "Pay order "
        '
        'dgv2
        '
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2.Location = New System.Drawing.Point(12, 372)
        Me.dgv2.Name = "dgv2"
        Me.dgv2.RowHeadersWidth = 51
        Me.dgv2.RowTemplate.Height = 24
        Me.dgv2.Size = New System.Drawing.Size(460, 323)
        Me.dgv2.TabIndex = 252
        '
        'dgv1
        '
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(504, 186)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowHeadersWidth = 51
        Me.dgv1.RowTemplate.Height = 24
        Me.dgv1.Size = New System.Drawing.Size(736, 341)
        Me.dgv1.TabIndex = 253
        '
        'btnview
        '
        Me.btnview.BackColor = System.Drawing.Color.Green
        Me.btnview.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnview.Location = New System.Drawing.Point(341, 186)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 32)
        Me.btnview.TabIndex = 262
        Me.btnview.Text = "View"
        Me.btnview.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Book Antiqua", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.LightGoldenrodYellow
        Me.Label2.Location = New System.Drawing.Point(498, 151)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(430, 32)
        Me.Label2.TabIndex = 261
        Me.Label2.Text = "Customer payments information"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Book Antiqua", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.LightGoldenrodYellow
        Me.Label3.Location = New System.Drawing.Point(12, 337)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(198, 32)
        Me.Label3.TabIndex = 265
        Me.Label3.Text = "Selected Items"
        '
        'txtpay
        '
        Me.txtpay.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtpay.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpay.ForeColor = System.Drawing.Color.Black
        Me.txtpay.Location = New System.Drawing.Point(752, 586)
        Me.txtpay.Multiline = True
        Me.txtpay.Name = "txtpay"
        Me.txtpay.Size = New System.Drawing.Size(176, 41)
        Me.txtpay.TabIndex = 266
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Uighur", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(620, 586)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(126, 56)
        Me.Label4.TabIndex = 267
        Me.Label4.Text = "Pay Rs:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Green
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(997, 148)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(99, 32)
        Me.Button1.TabIndex = 268
        Me.Button1.Text = "View All"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Pay_order
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources.square_cubism_form_shape
        Me.ClientSize = New System.Drawing.Size(1252, 734)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtpay)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.dgv2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl44444)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.btncontinue)
        Me.Controls.Add(Me.txtorderid)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Pay_order"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pay_order"
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnback As RoundButton
    Friend WithEvents btncontinue As RoundButton
    Friend WithEvents txtorderid As TextBox
    Friend WithEvents lbl44444 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents dgv2 As DataGridView
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents btnview As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtpay As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
End Class
