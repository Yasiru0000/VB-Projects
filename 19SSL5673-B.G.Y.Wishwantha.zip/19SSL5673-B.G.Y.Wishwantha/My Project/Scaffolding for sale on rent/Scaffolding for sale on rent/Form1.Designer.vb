﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnr = New System.Windows.Forms.Button()
        Me.btnp = New System.Windows.Forms.Button()
        Me.btnc = New System.Windows.Forms.Button()
        Me.btnu = New System.Windows.Forms.Button()
        Me.btnn = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 34.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Yellow
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(172, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(771, 67)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Rental Of Scaffolding Items"
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources._360_F_401796363_cC2yOhHHGT0qhdO6CPFt40VptyHaMUuo
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Location = New System.Drawing.Point(3, 12)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(170, 116)
        Me.Panel2.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightBlue
        Me.Panel1.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources.f44021_2373c2e9045847f88adf7b4e7094ab21_mv2
        Me.Panel1.Location = New System.Drawing.Point(179, 134)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(774, 496)
        Me.Panel1.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button1.ForeColor = System.Drawing.Color.Lime
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button1.Location = New System.Drawing.Point(0, 596)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(170, 34)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "System"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'btnr
        '
        Me.btnr.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnr.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources._1418802455_kkscaffolding_sale_rental_enterprise
        Me.btnr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnr.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnr.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnr.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnr.ForeColor = System.Drawing.Color.Lime
        Me.btnr.Image = CType(resources.GetObject("btnr.Image"), System.Drawing.Image)
        Me.btnr.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnr.Location = New System.Drawing.Point(0, 462)
        Me.btnr.Name = "btnr"
        Me.btnr.Size = New System.Drawing.Size(170, 60)
        Me.btnr.TabIndex = 5
        Me.btnr.Text = "Receiving Item "
        Me.btnr.UseVisualStyleBackColor = False
        '
        'btnp
        '
        Me.btnp.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnp.BackgroundImage = CType(resources.GetObject("btnp.BackgroundImage"), System.Drawing.Image)
        Me.btnp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnp.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnp.ForeColor = System.Drawing.Color.Lime
        Me.btnp.Image = CType(resources.GetObject("btnp.Image"), System.Drawing.Image)
        Me.btnp.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnp.Location = New System.Drawing.Point(0, 396)
        Me.btnp.Name = "btnp"
        Me.btnp.Size = New System.Drawing.Size(170, 60)
        Me.btnp.TabIndex = 4
        Me.btnp.Text = "Customer pay"
        Me.btnp.UseVisualStyleBackColor = False
        '
        'btnc
        '
        Me.btnc.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnc.BackgroundImage = CType(resources.GetObject("btnc.BackgroundImage"), System.Drawing.Image)
        Me.btnc.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnc.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnc.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnc.ForeColor = System.Drawing.Color.Lime
        Me.btnc.Image = CType(resources.GetObject("btnc.Image"), System.Drawing.Image)
        Me.btnc.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnc.Location = New System.Drawing.Point(0, 332)
        Me.btnc.Name = "btnc"
        Me.btnc.Size = New System.Drawing.Size(170, 60)
        Me.btnc.TabIndex = 3
        Me.btnc.Text = "Cancel order"
        Me.btnc.UseVisualStyleBackColor = False
        '
        'btnu
        '
        Me.btnu.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnu.BackgroundImage = CType(resources.GetObject("btnu.BackgroundImage"), System.Drawing.Image)
        Me.btnu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnu.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnu.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnu.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnu.ForeColor = System.Drawing.Color.Lime
        Me.btnu.Image = CType(resources.GetObject("btnu.Image"), System.Drawing.Image)
        Me.btnu.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnu.Location = New System.Drawing.Point(0, 266)
        Me.btnu.Name = "btnu"
        Me.btnu.Size = New System.Drawing.Size(170, 60)
        Me.btnu.TabIndex = 2
        Me.btnu.Text = "Update "
        Me.btnu.UseVisualStyleBackColor = False
        '
        'btnn
        '
        Me.btnn.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnn.BackgroundImage = CType(resources.GetObject("btnn.BackgroundImage"), System.Drawing.Image)
        Me.btnn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnn.ForeColor = System.Drawing.Color.Lime
        Me.btnn.Image = CType(resources.GetObject("btnn.Image"), System.Drawing.Image)
        Me.btnn.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnn.Location = New System.Drawing.Point(3, 134)
        Me.btnn.Name = "btnn"
        Me.btnn.Size = New System.Drawing.Size(170, 60)
        Me.btnn.TabIndex = 1
        Me.btnn.Text = "New Customer"
        Me.btnn.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button2.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources._1418802455_kkscaffolding_sale_rental_enterprise
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button2.ForeColor = System.Drawing.Color.Lime
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button2.Location = New System.Drawing.Point(0, 528)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(170, 60)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Exit"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Button3.ForeColor = System.Drawing.Color.Lime
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button3.Location = New System.Drawing.Point(0, 200)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(170, 60)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Select order"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources.square_cubism_form_shape
        Me.ClientSize = New System.Drawing.Size(954, 635)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnr)
        Me.Controls.Add(Me.btnp)
        Me.Controls.Add(Me.btnc)
        Me.Controls.Add(Me.btnu)
        Me.Controls.Add(Me.btnn)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Scaffolding for sale on rent"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnn As Button
    Friend WithEvents btnu As Button
    Friend WithEvents btnc As Button
    Friend WithEvents btnp As Button
    Friend WithEvents btnr As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
