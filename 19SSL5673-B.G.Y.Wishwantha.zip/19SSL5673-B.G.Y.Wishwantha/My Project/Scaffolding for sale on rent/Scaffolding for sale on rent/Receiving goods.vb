﻿Imports MySql.Data.MySqlClient

Public Class Receiving_item
    Public Sub populate()  '(datagired show order_items)
        Dim query3 As String = "SELECT * FROM order_items WHERE Order_Id = '" & txtorder_id.Text & "' "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub

    Public Sub populate2()  '(datagired show order_items)
        Dim query3 As String = "SELECT 	Order_Id, NIC FROM customer_order  "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnucancel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtid_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblname_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblid_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Receiving_item_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
        'Item name combobox list
        Dim quary2 As String = "SELECT Item_name FROM item"
        Using cmmd As New MySqlCommand(quary2, conn)
            Using reader As MySqlDataReader = cmmd.ExecuteReader()
                coitem.Items.Clear()
                While reader.Read()
                    coitem.Items.Add(reader("Item_name").ToString())
                End While
            End Using
        End Using

        'quantity lists and default=0 value
        For i As Integer = 0 To 2000

            coquan.Items.Add(i)
        Next

        populate2()
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        populate()
    End Sub

    Private Sub btncle_Click(sender As Object, e As EventArgs) Handles btncle.Click
        If String.IsNullOrEmpty(txtorder_id.Text) Then
            MessageBox.Show("Order Id is not given")

        ElseIf String.IsNullOrEmpty(coitem.Text) Then
            MessageBox.Show("Item Name is not given")

        ElseIf String.IsNullOrEmpty(coquan.Text) Then
            MessageBox.Show("Quantity is not given")

        Else

            cm = New MySqlCommand(
               "UPDATE item Set Current_quantity = Current_quantity+'" & coquan.Text & "' WHERE Item_name = '" & coitem.Text & "';" &
               "UPDATE order_items Set Quantity = Quantity-'" & coquan.Text & "' WHERE Order_Id = '" & txtorder_id.Text & "' And Item_name = '" & coitem.Text & "';", conn)

            cm.ExecuteNonQuery()
            MessageBox.Show("Receiving item successful")

            populate()
            populate2()
        End If
    End Sub
End Class