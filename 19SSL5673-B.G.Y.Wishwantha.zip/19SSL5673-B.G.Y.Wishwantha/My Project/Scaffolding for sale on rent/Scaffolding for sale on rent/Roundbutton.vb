﻿Imports System.Drawing.Drawing2D
Public Class RoundButton
    Inherits Button
    Public Sub New()
        Me.SetStyle(ControlStyles.UserPaint, True)

    End Sub

    Protected Overrides Sub OnPaint(pevent As PaintEventArgs)
        MyBase.OnPaint(pevent)
        Dim gr As GraphicsPath = New GraphicsPath()
        gr.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height)
        Me.Region = New Region(gr)

    End Sub


End Class
