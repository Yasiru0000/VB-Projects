﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class New_order
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(New_order))
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.txtmobile = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtp = New System.Windows.Forms.DateTimePicker()
        Me.btnreset = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnback = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnnext = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtnic = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblage = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(29, 180)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 39)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(29, 240)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 39)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Address"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(29, 301)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 39)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Mobile"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(29, 368)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(144, 39)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Date of birth"
        '
        'txtname
        '
        Me.txtname.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtname.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.ForeColor = System.Drawing.Color.Black
        Me.txtname.Location = New System.Drawing.Point(200, 180)
        Me.txtname.Multiline = True
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(373, 31)
        Me.txtname.TabIndex = 8
        '
        'txtaddress
        '
        Me.txtaddress.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtaddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaddress.ForeColor = System.Drawing.Color.Black
        Me.txtaddress.Location = New System.Drawing.Point(200, 240)
        Me.txtaddress.Multiline = True
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(373, 31)
        Me.txtaddress.TabIndex = 9
        '
        'txtmobile
        '
        Me.txtmobile.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtmobile.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmobile.ForeColor = System.Drawing.Color.Black
        Me.txtmobile.Location = New System.Drawing.Point(200, 301)
        Me.txtmobile.Multiline = True
        Me.txtmobile.Name = "txtmobile"
        Me.txtmobile.Size = New System.Drawing.Size(373, 31)
        Me.txtmobile.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(503, 368)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 39)
        Me.Label1.TabIndex = 145
        Me.Label1.Text = "Age"
        '
        'dtp
        '
        Me.dtp.CalendarFont = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp.CalendarForeColor = System.Drawing.Color.Blue
        Me.dtp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.dtp.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp.Location = New System.Drawing.Point(200, 376)
        Me.dtp.Name = "dtp"
        Me.dtp.Size = New System.Drawing.Size(280, 22)
        Me.dtp.TabIndex = 147
        Me.dtp.Value = New Date(2023, 7, 16, 0, 0, 0, 0)
        '
        'btnreset
        '
        Me.btnreset.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnreset.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnreset.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreset.ForeColor = System.Drawing.Color.Black
        Me.btnreset.Image = CType(resources.GetObject("btnreset.Image"), System.Drawing.Image)
        Me.btnreset.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnreset.Location = New System.Drawing.Point(634, 180)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(125, 57)
        Me.btnreset.TabIndex = 149
        Me.btnreset.Text = "Reset "
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'btnback
        '
        Me.btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.ForeColor = System.Drawing.Color.Black
        Me.btnback.Image = CType(resources.GetObject("btnback.Image"), System.Drawing.Image)
        Me.btnback.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnback.Location = New System.Drawing.Point(634, 116)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(125, 55)
        Me.btnback.TabIndex = 144
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btnnext
        '
        Me.btnnext.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnnext.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnnext.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnext.ForeColor = System.Drawing.Color.Black
        Me.btnnext.Image = CType(resources.GetObject("btnnext.Image"), System.Drawing.Image)
        Me.btnnext.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnnext.Location = New System.Drawing.Point(312, 432)
        Me.btnnext.Name = "btnnext"
        Me.btnnext.Size = New System.Drawing.Size(125, 55)
        Me.btnnext.TabIndex = 144
        Me.btnnext.Text = "Next"
        Me.btnnext.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(29, 125)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 39)
        Me.Label7.TabIndex = 150
        Me.Label7.Text = "NIC"
        '
        'txtnic
        '
        Me.txtnic.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtnic.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnic.ForeColor = System.Drawing.Color.Black
        Me.txtnic.Location = New System.Drawing.Point(200, 125)
        Me.txtnic.Multiline = True
        Me.txtnic.Name = "txtnic"
        Me.txtnic.Size = New System.Drawing.Size(373, 31)
        Me.txtnic.TabIndex = 151
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label8.Location = New System.Drawing.Point(122, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(550, 59)
        Me.Label8.TabIndex = 278
        Me.Label8.Text = "Add Customer Details"
        '
        'lblage
        '
        Me.lblage.AutoSize = True
        Me.lblage.BackColor = System.Drawing.Color.Transparent
        Me.lblage.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblage.ForeColor = System.Drawing.Color.White
        Me.lblage.Location = New System.Drawing.Point(584, 368)
        Me.lblage.Name = "lblage"
        Me.lblage.Size = New System.Drawing.Size(0, 39)
        Me.lblage.TabIndex = 279
        '
        'New_order
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources.square_cubism_form_shape
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(800, 499)
        Me.Controls.Add(Me.lblage)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtnic)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.dtp)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.txtmobile)
        Me.Controls.Add(Me.txtaddress)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.btnnext)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "New_order"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "New_order"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents txtaddress As TextBox
    Friend WithEvents txtmobile As TextBox
    Friend WithEvents btnback As RoundButton
    Friend WithEvents btnnext As RoundButton
    Friend WithEvents Label1 As Label
    Friend WithEvents dtp As DateTimePicker
    Friend WithEvents btnreset As RoundButton
    Friend WithEvents Label7 As Label
    Friend WithEvents txtnic As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents lblage As Label
End Class
