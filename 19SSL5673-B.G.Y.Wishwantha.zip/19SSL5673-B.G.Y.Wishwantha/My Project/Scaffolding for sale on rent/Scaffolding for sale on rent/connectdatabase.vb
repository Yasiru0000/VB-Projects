﻿Imports MySql.Data.MySqlClient

Module connectdatabase
    Public conn As MySqlConnection
    Public cm As MySqlCommand

    Sub connection()
        Try
            conn = New MySqlConnection("host=localhost;database=scaffolding_rental;username=root;password=")
            conn.Open()
            'MsgBox("connected to database")
        Catch ex As Exception
            MsgBox("connection failed")
        End Try
    End Sub
End Module

Module validation
    Function min_length(ByVal srt As String, ByVal length As Integer) As Boolean
        Dim result As Boolean = True
        If srt.Length < length Then
            result = False
        End If
        Return result
    End Function






End Module


