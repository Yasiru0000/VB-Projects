﻿Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Asn1.Misc

Public Class Update_order
    Private Sub btnback_Click(sender As Object, e As EventArgs)
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs)
        'update command denna
        Select_order.Show()
        Me.Hide()

    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtid_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblname_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblid_Click(sender As Object, e As EventArgs) Handles lblnic.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Update_order_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Nic combobox list
        connection()

        Dim quary As String = "SELECT NIC FROM customer"
        Using cmd As New MySqlCommand(quary, conn)
            Using reader As MySqlDataReader = cmd.ExecuteReader()
                conic.Items.Clear()
                While reader.Read()
                    conic.Items.Add(reader("NIC").ToString())
                End While
            End Using
        End Using
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub dtp_ValueChanged(sender As Object, e As EventArgs) Handles dtp.ValueChanged
        Dim datacheck As String
        Dim today As System.DateTime = System.DateTime.Now
        datacheck = dtp.Text

        Dim yearnow As Integer = today.Year
        Dim yeardtp As Integer = dtp.Value.Year
        Dim rightyear As Integer = dtp.Value.Year
        Dim minimage As Integer = yeardtp - rightyear
        Dim currentage As Integer = yearnow - yeardtp
        lblage.Text = currentage.ToString
        ' txtdob.Text = datacheck.ToString
        lblage.Show()
    End Sub

    Private Sub btnnext_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtage_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnupdate_Click_1(sender As Object, e As EventArgs) Handles btnupdate.Click
        Dim cusn, add, mob, age, NIC As String
        Dim datacheck As String

        NIC = conic.Text
        cusn = txtname.Text
        add = txtaddress.Text
        mob = txtmobile.Text
        age = lblage.Text
        datacheck = dtp.Text

        If min_length(NIC, 8) = False Then
            MsgBox("Need more charactors for NIC")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(cusn, 2) = False Then
            MsgBox("Need more charactors for name")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(add, 5) = False Then
            MsgBox("Need more charactors for address")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(mob, 10) = False Then
            MsgBox("Need more charactors for mobile number")
            MsgBox("Data don't saved succesfully")

        ElseIf min_length(datacheck, 9) = False Then
            MsgBox("Need more charactors for date of birth")
            MsgBox("Data don't saved succesfully")

        Else
            cm = New MySqlCommand("UPDATE customer SET Cus_name =@Cus_name, Address =@Address, Mobile =@Mobile, Dob =@Dob, Age =@Age WHERE NIC =@NIC", conn)

            cm.Parameters.AddWithValue("NIC", conic.Text)
            cm.Parameters.AddWithValue("Cus_name", txtname.Text)
            cm.Parameters.AddWithValue("Address", txtaddress.Text)
            cm.Parameters.AddWithValue("Mobile", txtmobile.Text)
            cm.Parameters.AddWithValue("Dob", dtp.Text)
            cm.Parameters.AddWithValue("Age", lblage.Text)

            cm.ExecuteNonQuery()
            MsgBox("Update Successful")
            Select_order.Show()
            Me.Hide()
        End If

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnback_Click_1(sender As Object, e As EventArgs) Handles btnback.Click
        Updaten.Show()
        Me.Hide()

    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        txtname.Text = ""
        txtaddress.Text = ""
        txtmobile.Text = ""
        lblage.Text = ""
        dtp.Text = ""
        conic.Text = ""
    End Sub
End Class