﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Admin_login
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If (txtun.Text = "Yasiru") And (txtp.Text = "12345") Then

            Manage_Items.Show()

            txtp.Text = ""
            txtun.Text = ""

            Me.Hide()
        Else
            txtp.Text = ""
            txtun.Text = ""

            MsgBox("Loggin Error")

            login.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub Admin_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtp_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtp_TextChanged_1(sender As Object, e As EventArgs) Handles txtp.TextChanged

    End Sub

    Private Sub CheckBox1_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            txtp.PasswordChar = ""
        Else
            txtp.PasswordChar = "•"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        login.Show()
        Me.Hide()

    End Sub
End Class