﻿Public Class Form1
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnr.Click
        Receiving_item.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnn.Click
        New_order.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnc.Click
        Update_Customer_Order.Show()
        Me.Hide()
    End Sub

    Private Sub btnu_Click(sender As Object, e As EventArgs) Handles btnu.Click
        'wenama update home pade ekak ona
        Updaten.Show()
        Me.Hide()

    End Sub

    Private Sub btnp_Click(sender As Object, e As EventArgs) Handles btnp.Click
        Pay_order.Show()
        Me.Hide()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        connection()

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        login.Show()
        Me.Hide()

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        Select_order.Show()
        Me.Hide()

    End Sub
End Class
