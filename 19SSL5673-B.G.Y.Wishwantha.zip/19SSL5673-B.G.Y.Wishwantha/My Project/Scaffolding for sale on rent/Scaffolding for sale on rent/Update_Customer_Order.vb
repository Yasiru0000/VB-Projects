﻿
Imports System.Drawing.Drawing2D
Imports MySql.Data.MySqlClient

Public Class Update_Customer_Order
    Public Sub populate()  '(datagired show order_items)
        Dim query3 As String = "SELECT * FROM order_items WHERE Order_Id = '" & txtorder_id.Text & "' "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub

    Public Sub populate2()  '(items table show  )
        Dim query4 As String = "SELECT Item_name, Current_quantity, Item_price FROM item "

        Using dapter2 As New MySqlDataAdapter(query4, conn)
            Dim datatable As New DataTable()
            dapter2.Fill(datatable)
            dgv1.DataSource = datatable
        End Using

    End Sub


    Private Sub btnupdate_Click(sender As Object, e As EventArgs)
        Select_order.Show()
        Me.Hide()

    End Sub

    Private Sub Update_Customer_Order_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
        ''customer_order datagird view
        Dim dt As New DataTable()
        dt.Columns.Add("Order Id")
        dt.Columns.Add("NIC")

        Dim userlist1 As List(Of Users) = Getusers1()
        For Each ro As Users In userlist1
            dt.Rows.Add(ro.Order_Id, ro.NIC)
        Next
        dgv3.DataSource = dt

        'items current information datagird view
        Dim dt2 As New DataTable()
        dt2.Columns.Add("Item Name")
        dt2.Columns.Add("Current Quantity")
        dt2.Columns.Add("Item Price")

        Dim userlist As List(Of Users) = Getusers()
        For Each r As Users In userlist
            dt2.Rows.Add(r.Item_name, r.Current_quantity, r.Item_price)
        Next
        dgv1.DataSource = dt2

        'Nic combobox list
        Dim quary As String = "SELECT NIC FROM customer"
        Using cmd As New MySqlCommand(quary, conn)
            Using reader As MySqlDataReader = cmd.ExecuteReader()
                conic.Items.Clear()
                While reader.Read()
                    conic.Items.Add(reader("NIC").ToString())
                End While
            End Using
        End Using

        'Item name combobox list
        Dim quary2 As String = "SELECT Item_name FROM item"
        Using cmmd As New MySqlCommand(quary2, conn)
            Using reader As MySqlDataReader = cmmd.ExecuteReader()
                coitem.Items.Clear()
                While reader.Read()
                    coitem.Items.Add(reader("Item_name").ToString())
                End While
            End Using
        End Using

        'quantity lists and default=0 value
        For i As Integer = 0 To 2000

            coquan.Items.Add(i)
        Next

        coquan.SelectedIndex = 0
        txtorderpr.Text = 0


        'Item price combobox list
        Dim quary5 As String = "SELECT Item_name, Item_price FROM item"
        Using cmmdd As New MySqlCommand(quary5, conn)
            Using reader As MySqlDataReader = cmmdd.ExecuteReader()
                coprice.Items.Clear()
                While reader.Read()
                    coprice.Items.Add(reader("Item_name").ToString())
                    coprice.Items.Add(reader("Item_price").ToString())
                End While
            End Using
        End Using

    End Sub

    Public Function Getusers1() As List(Of Users)
        ''customer_order datagird view
        Dim updatecustomer As New List(Of Users)
        connection()
        Dim cmm As New MySqlCommand
        Dim A = "SELECT * FROM `customer_order` "
        cmm = New MySqlCommand(A, conn)
        Dim result1 = cmm.ExecuteReader

        For Each i In result1
            updatecustomer.Add(New Users With {.Order_Id = result1("Order_Id"), .NIC = result1("NIC")})
        Next
        result1.Close()
        Return updatecustomer
    End Function

    Public Function Getusers() As List(Of Users)
        'for items current information datagird view 
        Dim selectorder As New List(Of Users)
        connection()
        Dim cm As New MySqlCommand
        Dim B = "SELECT * FROM `item` "
        cm = New MySqlCommand(B, conn)
        Dim result = cm.ExecuteReader

        For Each i In result
            selectorder.Add(New Users With {.Item_name = result("Item_name"), .Current_quantity = result("Current_quantity"), .Item_price = result("Item_price")})
        Next
        result.Close()
        Return selectorder
    End Function

    Private Sub RoundButton1_Click(sender As Object, e As EventArgs) Handles RoundButton1.Click
        Dim Quantityy, it As String

        Quantityy = coquan.Text
        it = coitem.Text


        If String.IsNullOrEmpty(txtorder_id.Text) Then
            MessageBox.Show("Order Id is not given")

        ElseIf String.IsNullOrEmpty(coitem.Text) Then
            MessageBox.Show("Item Name is not given")

        ElseIf Quantityy = 0 Then
            MessageBox.Show("Quantity is not given")

        ElseIf String.IsNullOrEmpty(coprice.Text) Then
            MessageBox.Show("Price is not given")


        Else
            'price calculate
            Dim v1 As Integer = Integer.Parse(coquan.Text)
            Dim v2 As Integer = Integer.Parse(coprice.Text)
            Dim re As Integer = v1 * v2
            txttotalprice.Text = re.ToString()

            Dim v3 As Integer = Integer.Parse(txtorderpr.Text)
            Dim re2 As Integer = re.ToString() + v3
            txtorderpr.Text = re2.ToString()


            cm = New MySqlCommand(
                "INSERT INTO order_items values(@Order_Id,@Item_name,@Quantity,@Total_Price);" &
                 "UPDATE item Set Current_quantity = Current_quantity-'" & coquan.Text & "' WHERE Item_name = '" & coitem.Text & "';", conn)
            cm.Parameters.AddWithValue("Order_Id", txtorder_id.Text)
            cm.Parameters.AddWithValue("Item_name", coitem.Text)
            cm.Parameters.AddWithValue("Quantity", coquan.Text)
            cm.Parameters.AddWithValue("Total_Price", txttotalprice.Text)

            cm.ExecuteNonQuery()
            MessageBox.Show("Item Selected")

            populate()
            populate2()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnview.Click

        populate()
    End Sub

    Private Sub btncle_Click(sender As Object, e As EventArgs) Handles btncle.Click
        If String.IsNullOrEmpty(txtorder_id.Text) Then
            MessageBox.Show("Order Id is not given")

        ElseIf String.IsNullOrEmpty(coitem.Text) Then
            MessageBox.Show("Item Name is not given")

        ElseIf String.IsNullOrEmpty(coprice.Text) Then
            MessageBox.Show("Price is not given")

        Else
            'price calculate
            Dim v1 As Integer = Integer.Parse(coquan.Text)
            Dim v2 As Integer = Integer.Parse(coprice.Text)
            Dim re As Integer = v1 * v2
            txttotalprice.Text = re.ToString()


            cm = New MySqlCommand(
               "UPDATE item Set Current_quantity = Current_quantity+'" & coquan.Text & "' WHERE Item_name = '" & coitem.Text & "';" &
               "UPDATE customer_pay Set Order_Price = Order_Price-'" & txttotalprice.Text & "' ,Amounts_Receivable = Amounts_Receivable-'" & txttotalprice.Text & "' WHERE Order_Id = '" & txtorder_id.Text & "';" &
               "DELETE FROM order_items WHERE Order_Id = '" & txtorder_id.Text & "' and Item_name = '" & coitem.Text & "' and Quantity = '" & coquan.Text & "';", conn)

            cm.ExecuteNonQuery()
            MessageBox.Show("Before Order Item Clear")

            populate()
            populate2()
        End If
    End Sub

    Private Sub btne_Click(sender As Object, e As EventArgs) Handles btne.Click
        Me.Close()
    End Sub

    Private Sub btnhome_Click(sender As Object, e As EventArgs) Handles btnhome.Click
        Form1.Show()
        Me.Close()

    End Sub

    Private Sub btnorder_Click(sender As Object, e As EventArgs) Handles btnorder.Click
        If String.IsNullOrEmpty(conic.Text) Then
            MessageBox.Show("Insert Customer NIC")

        ElseIf String.IsNullOrEmpty(txtnodr.Text) Then
            MessageBox.Show("Insert Number of days Required")

        Else

            Dim numberofdDys As Integer = Integer.Parse(txtnodr.Text)
            Dim currentDate As DateTime = DateTime.Now
            Dim LastDate As DateTime = currentDate.AddDays(numberofdDys)

            cm = New MySqlCommand("UPDATE customer_order Set NIC = '" & conic.Text & "' , Dates_Required = '" & txtnodr.Text & "' , Last_Date = @LastDate WHERE Order_Id = '" & txtorder_id.Text & "';", conn)
            cm.Parameters.AddWithValue("NIC", conic.Text)
            cm.Parameters.AddWithValue("Dates_Required", txtnodr.Text)
            cm.Parameters.AddWithValue("LastDate", LastDate)

            cm.ExecuteNonQuery()
            MessageBox.Show("Update order successful")
        End If

    End Sub

    Private Sub btnback_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnback_Click_1(sender As Object, e As EventArgs) Handles btnback.Click
        Updaten.Show()
        Me.Hide()

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub btnnadd_Click(sender As Object, e As EventArgs) Handles btnnadd.Click
        If String.IsNullOrEmpty(conic.Text) Then
            MessageBox.Show("Insert Customer NIC")

        ElseIf String.IsNullOrEmpty(txtnodr.Text) Then
            MessageBox.Show("Insert Number of days Required")

        ElseIf String.IsNullOrEmpty(txtorderpr.Text) Then
            MessageBox.Show("Select Items")

        Else
            cm = New MySqlCommand("UPDATE customer_pay Set Order_Price = Order_Price+'" & txtorderpr.Text & "' , Amounts_Receivable = Amounts_Receivable+'" & txtorderpr.Text & "'  WHERE Order_Id = '" & txtorder_id.Text & "';", conn)



            cm.ExecuteNonQuery()
            MessageBox.Show("Add successful")
        End If
    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        txtorder_id.Text = ""
        conic.Text = ""
        txtnodr.Text = ""
        txtorderpr.Text = 0
        txttotalprice.Text = ""
        coitem.Text = ""
        coquan.Text = ""
        coprice.Text = ""
    End Sub

    Private Sub RoundButton2_Click(sender As Object, e As EventArgs) Handles RoundButton2.Click
        If String.IsNullOrEmpty(txtorder_id.Text) Then
            MessageBox.Show("Order Id is not given")


        Else
            cm = New MySqlCommand(
                "DELETE FROM customer_order WHERE Order_Id = '" & txtorder_id.Text & "';" &
                "DELETE FROM customer_pay WHERE Order_Id = '" & txtorder_id.Text & "';", conn)



            cm.ExecuteNonQuery()
            MessageBox.Show(" successful")



        End If

    End Sub
End Class