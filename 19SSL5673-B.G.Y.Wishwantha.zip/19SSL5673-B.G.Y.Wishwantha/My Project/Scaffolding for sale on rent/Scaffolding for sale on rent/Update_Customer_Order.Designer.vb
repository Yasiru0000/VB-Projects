﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Update_Customer_Order
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Update_Customer_Order))
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.coquan = New System.Windows.Forms.ComboBox()
        Me.coitem = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        Me.txtorder_id = New System.Windows.Forms.TextBox()
        Me.lbl44444 = New System.Windows.Forms.Label()
        Me.conic = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtnodr = New System.Windows.Forms.TextBox()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblid = New System.Windows.Forms.Label()
        Me.dgv3 = New System.Windows.Forms.DataGridView()
        Me.btncle = New System.Windows.Forms.Button()
        Me.btnview = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.coprice = New System.Windows.Forms.ComboBox()
        Me.txttotalprice = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtorderpr = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.RoundButton2 = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnreset = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnnadd = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.RoundButton1 = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btne = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnhome = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnback = New Scaffolding_for_sale_on_rent.RoundButton()
        Me.btnorder = New Scaffolding_for_sale_on_rent.RoundButton()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label6.Location = New System.Drawing.Point(62, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(1120, 59)
        Me.Label6.TabIndex = 165
        Me.Label6.Text = "Change and Upadate Customer Select Order"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Book Antiqua", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.LightGoldenrodYellow
        Me.Label2.Location = New System.Drawing.Point(596, 346)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(198, 32)
        Me.Label2.TabIndex = 255
        Me.Label2.Text = "Selected Items"
        '
        'coquan
        '
        Me.coquan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coquan.FormattingEnabled = True
        Me.coquan.Location = New System.Drawing.Point(883, 134)
        Me.coquan.Name = "coquan"
        Me.coquan.Size = New System.Drawing.Size(110, 28)
        Me.coquan.TabIndex = 253
        '
        'coitem
        '
        Me.coitem.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coitem.FormattingEnabled = True
        Me.coitem.Location = New System.Drawing.Point(693, 134)
        Me.coitem.Name = "coitem"
        Me.coitem.Size = New System.Drawing.Size(176, 28)
        Me.coitem.TabIndex = 252
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(876, 92)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(108, 39)
        Me.Label13.TabIndex = 251
        Me.Label13.Text = "Quantity"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(686, 92)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(127, 39)
        Me.Label12.TabIndex = 250
        Me.Label12.Text = "Item Name"
        '
        'dgv2
        '
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2.Location = New System.Drawing.Point(602, 381)
        Me.dgv2.Name = "dgv2"
        Me.dgv2.RowHeadersWidth = 51
        Me.dgv2.RowTemplate.Height = 24
        Me.dgv2.Size = New System.Drawing.Size(467, 298)
        Me.dgv2.TabIndex = 249
        '
        'txtorder_id
        '
        Me.txtorder_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorder_id.Location = New System.Drawing.Point(145, 112)
        Me.txtorder_id.Multiline = True
        Me.txtorder_id.Name = "txtorder_id"
        Me.txtorder_id.Size = New System.Drawing.Size(176, 29)
        Me.txtorder_id.TabIndex = 248
        '
        'lbl44444
        '
        Me.lbl44444.AutoSize = True
        Me.lbl44444.BackColor = System.Drawing.Color.Transparent
        Me.lbl44444.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl44444.ForeColor = System.Drawing.Color.White
        Me.lbl44444.Location = New System.Drawing.Point(12, 102)
        Me.lbl44444.Name = "lbl44444"
        Me.lbl44444.Size = New System.Drawing.Size(108, 39)
        Me.lbl44444.TabIndex = 247
        Me.lbl44444.Text = "Order Id "
        '
        'conic
        '
        Me.conic.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.conic.FormattingEnabled = True
        Me.conic.Location = New System.Drawing.Point(145, 154)
        Me.conic.Name = "conic"
        Me.conic.Size = New System.Drawing.Size(176, 28)
        Me.conic.TabIndex = 246
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(13, 702)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(398, 39)
        Me.Label3.TabIndex = 245
        Me.Label3.Text = "Number of days Required From Today"
        '
        'txtnodr
        '
        Me.txtnodr.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnodr.Location = New System.Drawing.Point(459, 702)
        Me.txtnodr.Multiline = True
        Me.txtnodr.Name = "txtnodr"
        Me.txtnodr.Size = New System.Drawing.Size(91, 30)
        Me.txtnodr.TabIndex = 244
        '
        'dgv1
        '
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(20, 381)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowHeadersWidth = 51
        Me.dgv1.RowTemplate.Height = 24
        Me.dgv1.Size = New System.Drawing.Size(467, 298)
        Me.dgv1.TabIndex = 243
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Book Antiqua", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.LightGoldenrodYellow
        Me.Label1.Location = New System.Drawing.Point(14, 314)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(396, 64)
        Me.Label1.TabIndex = 241
        Me.Label1.Text = "Items,there current quantities " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and prices"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.BackColor = System.Drawing.Color.Transparent
        Me.lblid.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.ForeColor = System.Drawing.Color.White
        Me.lblid.Location = New System.Drawing.Point(12, 154)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(59, 39)
        Me.lblid.TabIndex = 237
        Me.lblid.Text = "NIC"
        '
        'dgv3
        '
        Me.dgv3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv3.Location = New System.Drawing.Point(340, 102)
        Me.dgv3.Name = "dgv3"
        Me.dgv3.RowHeadersWidth = 51
        Me.dgv3.RowTemplate.Height = 24
        Me.dgv3.Size = New System.Drawing.Size(340, 150)
        Me.dgv3.TabIndex = 256
        '
        'btncle
        '
        Me.btncle.BackColor = System.Drawing.Color.Green
        Me.btncle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncle.Location = New System.Drawing.Point(709, 189)
        Me.btncle.Name = "btncle"
        Me.btncle.Size = New System.Drawing.Size(205, 63)
        Me.btncle.TabIndex = 258
        Me.btncle.Text = "Delete all previously selected quantities"
        Me.btncle.UseVisualStyleBackColor = False
        '
        'btnview
        '
        Me.btnview.BackColor = System.Drawing.Color.Green
        Me.btnview.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnview.Location = New System.Drawing.Point(800, 344)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 32)
        Me.btnview.TabIndex = 259
        Me.btnview.Text = "View"
        Me.btnview.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(1001, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 39)
        Me.Label5.TabIndex = 262
        Me.Label5.Text = "Price:"
        '
        'coprice
        '
        Me.coprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coprice.FormattingEnabled = True
        Me.coprice.Location = New System.Drawing.Point(1008, 134)
        Me.coprice.Name = "coprice"
        Me.coprice.Size = New System.Drawing.Size(162, 28)
        Me.coprice.TabIndex = 261
        '
        'txttotalprice
        '
        Me.txttotalprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttotalprice.Location = New System.Drawing.Point(1012, 302)
        Me.txttotalprice.Multiline = True
        Me.txttotalprice.Name = "txttotalprice"
        Me.txttotalprice.Size = New System.Drawing.Size(108, 29)
        Me.txttotalprice.TabIndex = 264
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(807, 302)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(161, 39)
        Me.Label4.TabIndex = 263
        Me.Label4.Text = "Total Price Rs:"
        '
        'txtorderpr
        '
        Me.txtorderpr.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorderpr.Location = New System.Drawing.Point(876, 702)
        Me.txtorderpr.Multiline = True
        Me.txtorderpr.Name = "txtorderpr"
        Me.txtorderpr.Size = New System.Drawing.Size(108, 29)
        Me.txtorderpr.TabIndex = 266
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Uighur", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(604, 695)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(240, 39)
        Me.Label7.TabIndex = 265
        Me.Label7.Text = "Change order price Rs:"
        '
        'RoundButton2
        '
        Me.RoundButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RoundButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.RoundButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoundButton2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.RoundButton2.Image = CType(resources.GetObject("RoundButton2.Image"), System.Drawing.Image)
        Me.RoundButton2.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.RoundButton2.Location = New System.Drawing.Point(1115, 595)
        Me.RoundButton2.Name = "RoundButton2"
        Me.RoundButton2.Size = New System.Drawing.Size(137, 71)
        Me.RoundButton2.TabIndex = 269
        Me.RoundButton2.Text = "Cancel order"
        Me.RoundButton2.UseVisualStyleBackColor = True
        '
        'btnreset
        '
        Me.btnreset.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnreset.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnreset.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreset.ForeColor = System.Drawing.Color.Black
        Me.btnreset.Image = CType(resources.GetObject("btnreset.Image"), System.Drawing.Image)
        Me.btnreset.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnreset.Location = New System.Drawing.Point(196, 188)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(125, 57)
        Me.btnreset.TabIndex = 268
        Me.btnreset.Text = "Reset "
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'btnnadd
        '
        Me.btnnadd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnnadd.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnadd.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnnadd.Image = CType(resources.GetObject("btnnadd.Image"), System.Drawing.Image)
        Me.btnnadd.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnnadd.Location = New System.Drawing.Point(994, 695)
        Me.btnnadd.Name = "btnnadd"
        Me.btnnadd.Size = New System.Drawing.Size(75, 49)
        Me.btnnadd.TabIndex = 267
        Me.btnnadd.Text = "Add "
        Me.btnnadd.UseVisualStyleBackColor = True
        '
        'RoundButton1
        '
        Me.RoundButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RoundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.RoundButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RoundButton1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RoundButton1.Image = CType(resources.GetObject("RoundButton1.Image"), System.Drawing.Image)
        Me.RoundButton1.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.RoundButton1.Location = New System.Drawing.Point(923, 188)
        Me.RoundButton1.Name = "RoundButton1"
        Me.RoundButton1.Size = New System.Drawing.Size(129, 66)
        Me.RoundButton1.TabIndex = 254
        Me.RoundButton1.Text = "New Add"
        Me.RoundButton1.UseVisualStyleBackColor = True
        '
        'btne
        '
        Me.btne.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btne.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btne.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btne.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btne.Image = CType(resources.GetObject("btne.Image"), System.Drawing.Image)
        Me.btne.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btne.Location = New System.Drawing.Point(1115, 503)
        Me.btne.Name = "btne"
        Me.btne.Size = New System.Drawing.Size(137, 55)
        Me.btne.TabIndex = 242
        Me.btne.Text = "Exit"
        Me.btne.UseVisualStyleBackColor = True
        '
        'btnhome
        '
        Me.btnhome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnhome.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnhome.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnhome.Image = CType(resources.GetObject("btnhome.Image"), System.Drawing.Image)
        Me.btnhome.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnhome.Location = New System.Drawing.Point(1115, 442)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(137, 55)
        Me.btnhome.TabIndex = 240
        Me.btnhome.Text = "Home"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'btnback
        '
        Me.btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnback.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnback.Image = CType(resources.GetObject("btnback.Image"), System.Drawing.Image)
        Me.btnback.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnback.Location = New System.Drawing.Point(1115, 381)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(137, 55)
        Me.btnback.TabIndex = 239
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btnorder
        '
        Me.btnorder.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnorder.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnorder.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnorder.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnorder.Image = CType(resources.GetObject("btnorder.Image"), System.Drawing.Image)
        Me.btnorder.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnorder.Location = New System.Drawing.Point(1115, 672)
        Me.btnorder.Name = "btnorder"
        Me.btnorder.Size = New System.Drawing.Size(137, 72)
        Me.btnorder.TabIndex = 238
        Me.btnorder.Text = "Update Order"
        Me.btnorder.UseVisualStyleBackColor = True
        '
        'Update_Customer_Order
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Scaffolding_for_sale_on_rent.My.Resources.Resources.square_cubism_form_shape
        Me.ClientSize = New System.Drawing.Size(1270, 764)
        Me.Controls.Add(Me.RoundButton2)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.btnnadd)
        Me.Controls.Add(Me.txtorderpr)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txttotalprice)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.coprice)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.btncle)
        Me.Controls.Add(Me.dgv3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RoundButton1)
        Me.Controls.Add(Me.coquan)
        Me.Controls.Add(Me.coitem)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.dgv2)
        Me.Controls.Add(Me.txtorder_id)
        Me.Controls.Add(Me.lbl44444)
        Me.Controls.Add(Me.conic)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtnodr)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.btne)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnhome)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.btnorder)
        Me.Controls.Add(Me.lblid)
        Me.Controls.Add(Me.Label6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Update_Customer_Order"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Update_Customer_Order"
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label6 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents RoundButton1 As RoundButton
    Friend WithEvents coquan As ComboBox
    Friend WithEvents coitem As ComboBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents dgv2 As DataGridView
    Friend WithEvents txtorder_id As TextBox
    Friend WithEvents lbl44444 As Label
    Friend WithEvents conic As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtnodr As TextBox
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents btne As RoundButton
    Friend WithEvents Label1 As Label
    Friend WithEvents btnhome As RoundButton
    Friend WithEvents btnback As RoundButton
    Friend WithEvents btnorder As RoundButton
    Friend WithEvents lblid As Label
    Friend WithEvents dgv3 As DataGridView
    Friend WithEvents btncle As Button
    Friend WithEvents btnview As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents coprice As ComboBox
    Friend WithEvents txttotalprice As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnnadd As RoundButton
    Friend WithEvents txtorderpr As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents btnreset As RoundButton
    Friend WithEvents RoundButton2 As RoundButton
End Class
