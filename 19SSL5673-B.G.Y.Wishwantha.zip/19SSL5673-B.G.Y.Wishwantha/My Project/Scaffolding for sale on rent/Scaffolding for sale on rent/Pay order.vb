﻿Imports MySql.Data.MySqlClient

Public Class Pay_order



    Public Sub populate()  '(datagired show customer_pay)
        Dim query3 As String = "SELECT * FROM customer_pay WHERE Order_Id = '" & txtorderid.Text & "' "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using
    End Sub

    Public Sub populate3()  '(datagired show customer_pay)
        Dim query3 As String = "SELECT * FROM customer_pay  "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv1.DataSource = datatable
        End Using
    End Sub

    Public Sub populate2()  '(datagired show order_items)
        Dim query3 As String = "SELECT * FROM order_items WHERE Order_Id = '" & txtorderid.Text & "' "

        Using dapter As New MySqlDataAdapter(query3, conn)
            Dim datatable As New DataTable()
            dapter.Fill(datatable)
            dgv2.DataSource = datatable
        End Using

    End Sub

    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btncontinue_Click(sender As Object, e As EventArgs) Handles btncontinue.Click
        If String.IsNullOrEmpty(txtorderid.Text) Then
            MessageBox.Show("Order Id is not given")

            '   ElseIf String.IsNullOrEmpty(conic.Text) Then
            '   MessageBox.Show("NIC is not given")

        Else
            cm = New MySqlCommand(
                "UPDATE customer_pay Set Cus_Pay = Cus_Pay+'" & txtpay.Text & "' ,  Amounts_Receivable = Amounts_Receivable-'" & txtpay.Text & "' WHERE Order_Id = '" & txtorderid.Text & "';", conn)

            cm.ExecuteNonQuery()
            MessageBox.Show("Payment successful.Thank You!!!!!.Order again")

            populate()
            populate2()
        End If

    End Sub

    Private Sub Pay_order_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection()
        populate3()
    End Sub

    Private Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        If String.IsNullOrEmpty(txtorderid.Text) Then
            MessageBox.Show("Order Id is not given")

        Else

            populate()
            populate2()

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        populate3()
    End Sub
End Class